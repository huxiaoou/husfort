# Description

HUSFORT is "Handy & Utility Solution For Operation, Research and Trading" for short.

This project is designed to provide some highly frequently used tools in daily quantitative trading works.

---

## Build and Install

```powershell
python setup.py build
python setup.py sdist
pip install .\dist\husfort-1.0.0.tar.gz
```